﻿ميديفال داينستي (Medieval Dynasty) — التعريب الكامل
تعريب: عبدالله هادي

التعريب كامل: 40693 نصا من أصل 40706 (القوائم، الحوارات، المهام، السجل، الإرشادات، أسماء الأغراض والمباني).
الأسطر الثلاثة عشر الباقية أسماء علامات تجارية أو مفاتيح لوحة المفاتيح تبقى بالإنجليزية عمدا.
العربية لغة مستقلة تظهر في قائمة اللغات، ولا تحل محل أي لغة أخرى.
هذا التعريب لنسخة Steam (رقم البناء 25776186).

التثبيت:
1) أغلق اللعبة تماما.
2) في Steam: زر يمين على Medieval Dynasty ← إدارة ← استعراض الملفات المحلية.
3) انسخ المجلد Medieval_Dynasty من هذا الملف المضغوط والصقه داخل مجلد اللعبة.
   (يضيف ملفا واحدا فقط: Medieval_Dynasty\Content\Paks\Medieval_Dynasty-WindowsNoEditor_P.pak
   ولا يستبدل أي ملف من ملفات اللعبة الأصلية.)
4) في Steam: زر يمين على اللعبة ← خصائص ← عام ← خيارات التشغيل، واكتب:
   -fileopenlog
   (هذا الخيار ضروري؛ بدونه تتجاهل اللعبة ملف التعريب.)
5) شغل اللعبة: الإعدادات (Settings) ← اللعبة (Game) ← اللغة (Language) ← اختر «العربية».

إلغاء التثبيت:
- احذف الملف Medieval_Dynasty\Content\Paks\Medieval_Dynasty-WindowsNoEditor_P.pak
  وأزل -fileopenlog من خيارات التشغيل. لا يُمس أي ملف أصلي.

ملاحظات:
- إذا حدّثت Steam اللعبة إلى بناء جديد فقد تظهر نصوص جديدة بالإنجليزية حتى يصدر تحديث للتعريب.
- الأرقام داخل اللعبة تظهر بالأرقام العربية المشرقية (٠١٢٣) لأن اللعبة تنسقها حسب اللغة.

الخط: Almarai Bold (رخصة SIL OFL، النص في OFL.txt).
الحقوق: هذا التعريب من عمل عبدالله هادي. يمنع إعادة نشره أو نسبه لغير صاحبه.

------------------------------------------------------------
Medieval Dynasty — full Arabic translation
Translation by Abdullah Hadi (عبدالله هادي)

Complete: 40,693 of 40,706 strings (menus, dialogue, quests, journal, tutorials, item and building names). The 13
remaining rows are brand names and key names that stay English on purpose. Arabic is a separate language in the
language menu; no other language is replaced. For the Steam version (build 25776186).

Install:
1) Close the game.
2) Steam: right-click Medieval Dynasty -> Manage -> Browse local files.
3) Copy the Medieval_Dynasty folder from this zip into the game folder. It adds ONE file
   (Medieval_Dynasty\Content\Paks\Medieval_Dynasty-WindowsNoEditor_P.pak) and replaces nothing.
4) Steam: right-click the game -> Properties -> General -> Launch Options, and enter:
   -fileopenlog
   (Required: without it the game ignores the translation file.)
5) Start the game: Settings -> Game -> Language -> "العربية".

Uninstall: delete Medieval_Dynasty\Content\Paks\Medieval_Dynasty-WindowsNoEditor_P.pak and remove -fileopenlog
from the launch options. No original file is touched.

Notes: a Steam update to a newer build may add new English strings until the translation is updated. In-game
numbers use Eastern Arabic digits (٠١٢٣) because the game formats them per language.

Font: Almarai Bold (SIL Open Font License; text in OFL.txt).
Rights: this translation is the work of Abdullah Hadi. Do not redistribute it or credit it to anyone else.
